/**
 * REGISTER PAGE CONTROLLER
 */

app.controller('lockscreenPageCtrl', function($location, $scope, $rootScope) {

    $rootScope.hideLeftMenu = true;
    $rootScope.hideTopMenu = true;
    $rootScope.showFooter = false;

});