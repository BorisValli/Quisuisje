/**
 * REGISTER PAGE CONTROLLER
 */

app.controller('registerPageCtrl', function($location, $scope, $rootScope) {

    $rootScope.hideLeftMenu = true;
    $rootScope.hideTopMenu = true;
    $rootScope.showFooter = false;

});