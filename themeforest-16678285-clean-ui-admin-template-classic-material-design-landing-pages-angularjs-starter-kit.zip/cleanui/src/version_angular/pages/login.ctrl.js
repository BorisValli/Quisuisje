/**
 * LOGIN PAGE CONTROLLER
 */

app.controller('loginPageCtrl', function($location, $scope, $rootScope) {

    $rootScope.hideLeftMenu = true;
    $rootScope.hideTopMenu = true;
    $rootScope.showFooter = false;

});